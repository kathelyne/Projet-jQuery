 //Le background change de couleur lorsque l'on appuie sur une lettre
 var bg = $("#particles-js");

 $(document).keydown(function() {
     $(bg).css("background-color", getRandomColor);
 });


 function getRandomColor() {
     var letters = "0123456789ABCDEF";
     var color = "#";
     for (var i = 0; i < 6; i++) {
         color += letters[Math.floor(Math.random() * 16)];
     }
     return color;
 }
 // renvoi le nom de l'artiste lorsqu'on clique sur l'image
 $(".img").on("click", function() {
     var name = $(this).attr("name");
     const initial = name.charAt(0).toUpperCase(); // changer la premier lettre en majuscule
     const nameCapital = initial + name.slice(1);
     $("#titre").text(nameCapital);

     // Effet de rebond sur l'image, déja défini en CSS, activable avec jQuery via un click
     $(this).toggleClass("flash");

     // Jouer de la musique avec un click

     var music = $(this).attr("name");
     music += ".mp3";
     playMusic(music);



 });

 //Lancer la musique
 $("#btn").click(function() {
     var artiste = $("#input").val();
     var music = artiste + ".mp3";
     playMusic(music);

 });

 function playMusic(music) {
     var audio = new Audio(music);
     audio.play();
 }